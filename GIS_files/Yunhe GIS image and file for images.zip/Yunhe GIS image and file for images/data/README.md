The data

the cences data is which year?  https://www.kaggle.com/muonneutrino/new-york-city-census-data#census_block_loc.csv

the weather data is 2015? (I need to double check) https://www.kaggle.com/meinertsen/nyc-hourly-weather-data/data

the LEHD data (from our prof) is which year? 

traffic speed data (201504-201512) (too big, I need to clean it before upload,T_T) http://data.beta.nyc/zh_CN/dataset/nyc-real-time-traffic-speed-data-feed-archived

subway https://data.cityofnewyork.us/Transportation/Subway-Stations/arq3-7z49
